#pragma once

void playMastermind();
int checkCharactersAndPosition(string a, string b);
int checkCharacters(string a, string b);