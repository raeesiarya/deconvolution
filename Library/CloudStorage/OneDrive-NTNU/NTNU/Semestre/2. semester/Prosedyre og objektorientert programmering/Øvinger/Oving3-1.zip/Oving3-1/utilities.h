#pragma once

int randomWithLimits(int ngrense,int ogrense);