#pragma once
#include "std_lib_facilities.h"
#include "AnimationWindow.h"

// Abstrakt klasse. Arvende konkrete klasser må implementere funksjonen draw()
// som tegner former i vinduet de skal bli vist i.
class Emoji {
public:
    virtual void draw(AnimationWindow&) = 0;
    virtual ~Emoji(){}; //destruktør
};

class Face : Emoji {
protected:
    Point centre;
    int radius;
public:
    Face(Point c, int r) : centre(c), radius(r) {};
    void draw(AnimationWindow&) = 0;
    //void draw(AnimationWindow&) override;
};