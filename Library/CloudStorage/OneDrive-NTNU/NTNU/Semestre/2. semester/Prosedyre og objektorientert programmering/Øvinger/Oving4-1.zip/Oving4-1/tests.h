#pragma once

//Oppgave 1
void testCallByValue();
void testCallByReference();
//-------------

//Oppgave 2

//Oppgave 3

void testString();

char randomizeString();
