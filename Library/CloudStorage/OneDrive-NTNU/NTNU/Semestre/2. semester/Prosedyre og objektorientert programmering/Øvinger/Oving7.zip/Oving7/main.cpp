#include "std_lib_facilities.h"
#include "animal.h"
#include "Emoji.h"

//int main() {
//1--------------------------------------------------------
    /*
    vector<std::unique_ptr<Dog>> v;

    v.emplace_back(std::make_unique<Dog>("Hus", 10));
    v.emplace_back(std::make_unique<Dog>("Lus", 15));
    v.emplace_back(std::make_unique<Dog>("Rus", 17));

    for(int i = 0; i < v.size(); i++) {
        cout << v.at(i) ->toString() << endl;
    }


    //Animal a{"Vann",10};
    Dog d{"Sy",3};
    Cat c{"Py",1};

    //cout << a.toString() << endl;
    cout << d.toString() << endl;
    cout << c.toString() << endl;
*/
//---------------------------------------------------------



//3--------------------------------------------------------


//---------------------------------------------------------


//    return 0;
//}