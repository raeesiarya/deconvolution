#include "blackjack.h"
#include "Card.h"
#include "CardDeck.h"
#include <iostream>

bool isAce(Card card) {
    return card.getRank() == Rank::ace;
}

int BlackJack::getCardValue(Card kort) {
    if(isAce(kort) == 1) {
        return 11;
    }
    else {
        //return kort;
        return static_cast<int>(kort.getRank());
    }
}

int getHandScore(std::vector<Card> kortt) {
    int poeng = 0;
    int essp = 0;
    for(int i = 0; i < kortt.size(); i++) {
        if(isAce(kortt.at(i)) == 1) {
            essp++;
            if(essp % 2 == 0) {
                poeng++;
            }
            else {
                poeng += 11;
            }
        }
        else {
            BlackJack blackjack;
            int ppp = blackjack.getCardValue(kortt.at(i));
            poeng += ppp;
        }
    }
    return poeng;
}