#include "Emoji.h"

void Face::draw(AnimationWindow&) {
    AnimationWindow win(800,600);
    win.draw_circle(centre,radius,Color::yellow);
    win.wait_for_close();
}