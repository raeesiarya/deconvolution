class breakCCompiler;int main(void) { return 0; }
